import React from 'react'
import "../../styles/Home/knowmore.css"
function Knowmore() {
    return (
        <>
            <div className='knowmore_main_div' >
                <div className='knowmore_heading'  >"SF Foods: Where Every Dish tells a story"</div>
                <div className='click_buttons' >KNOW MORE </div>

            </div>
        </>
    )
}

export default Knowmore