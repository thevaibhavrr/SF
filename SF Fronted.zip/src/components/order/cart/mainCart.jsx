import React from 'react'
import CartItem from './cartItem'
import Orderbar from '../orderbar/orderbar'


function MainCart() {
  return (
    <div style={{minHeight:"100vh" }}  >
        <CartItem/>
        
    </div>
  )
}

export default MainCart