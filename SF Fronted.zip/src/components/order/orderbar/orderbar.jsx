import React, { useState } from 'react';
import "../../../styles/order/orderbar.css";

function Orderbar({activeOptionName}) {
  // const [activeOption, setActiveOption] = useState('CART');

  // const handleOptionClick = (option) => {
  //   setActiveOption(option);
  // };
const activeOption = activeOptionName
  return (
    <>
      <div className='main_orderbar_div'>
        <div
          className={activeOption === 'CART' ? 'active' : ''}
        >
          CART
        </div>
        <div className='orderbar_line'></div>
        <div
          className={activeOption === 'CHECKOUT' ? 'active' : ''}
        >
          CHECKOUT
        </div>
        <div className='orderbar_line'></div>
        <div
          className={activeOption === 'PAYMENT' ? 'active' : ''}
        >
          PAYMENT
        </div>
      </div>
    </>
  );
}

export default Orderbar;
