import React from 'react'
import "../../styles/loaders/horizotalLoader.css"
function HorizotalLoader() {
  return (
    <div>
        <div class="Horizontal_Loader"></div>

    </div>
  )
}

export default HorizotalLoader