import React from 'react'
import "../../styles/loaders/Heartloader.css"
function Heartloader() {
  return (
    <div>
 <div class="heart_loader"></div> 

    </div>

  )
}

export default Heartloader